from flask import Flask, render_template, request, redirect, session, jsonify
import sqlite3
import os
import subprocess
import uuid
from datetime import datetime, timedelta

app = Flask(__name__)
app.secret_key = "secret123"

# -----------------------------------------------
# Ensure temp folder exists
# -----------------------------------------------
TEMP_DIR = "temp_runs"
if not os.path.exists(TEMP_DIR):
    os.makedirs(TEMP_DIR)


# -----------------------------------------------
# DATABASE INITIALIZATION
# -----------------------------------------------
def init_db():
    if not os.path.exists("platform.db"):
        conn = sqlite3.connect("platform.db")
        c = conn.cursor()

        # Users table
        c.execute("""
    CREATE TABLE users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        email TEXT UNIQUE,
        password TEXT,
        course TEXT,
        role TEXT,
        total_score INTEGER DEFAULT 0,
        status TEXT DEFAULT 'active'
    );
""")


        # Challenges
        c.execute("""
        CREATE TABLE challenges (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            course TEXT,
            module TEXT,
            title TEXT,
            level TEXT,
            description TEXT,
            sample_input TEXT,
            sample_output TEXT,
            hidden_tests TEXT,
            language TEXT
        );
        """)

        # Submissions
        c.execute("""
        CREATE TABLE submissions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            challenge_id INTEGER,
            code TEXT,
            language TEXT,
            status TEXT,
            score INTEGER,
            time_taken INTEGER DEFAULT 0,
            submitted_at TEXT
        );
        """)

        # Badges
        c.execute("""
        CREATE TABLE badges (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            badge_name TEXT,
            awarded_at TEXT
        );
        """)

        # Streaks (daily solve log)
        c.execute("""
        CREATE TABLE streaks (
            user_id INTEGER,
            date TEXT,
            PRIMARY KEY(user_id, date)
        );
        """)

        # Code history (Run + Submit snapshots)
        c.execute("""
        CREATE TABLE code_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            challenge_id INTEGER,
            code TEXT,
            action TEXT,
            timestamp TEXT
        );
        """)

        # Discussions
        c.execute("""
        CREATE TABLE discussions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            challenge_id INTEGER,
            user_id INTEGER,
            comment TEXT,
            posted_at TEXT
        );
        """)

        # Admin user
        c.execute("""
        INSERT INTO users(name,email,password,course,role,total_score)
        VALUES ('Admin','admin@gmail.com','admin123','none','admin',0)
        """)

        conn.commit()
        conn.close()


init_db()


# -----------------------------------------------
# DB helper
# -----------------------------------------------
def get_db():
    conn = sqlite3.connect("platform.db")
    conn.row_factory = sqlite3.Row
    return conn


# -----------------------------------------------
# AUTH ROUTES
# -----------------------------------------------
@app.route("/")
def home():
    return "<h2>Platform Running</h2><a href='/login'>Login</a>"


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        conn = get_db()
        user = conn.execute(
            "SELECT * FROM users WHERE email=? AND password=?",
            (request.form["email"], request.form["password"])
        ).fetchone()
        conn.close()

        if user:
            session["user_id"] = user["id"]
            session["name"] = user["name"]
            session["role"] = user["role"]
            session["course"] = user["course"]
            return redirect("/admin_dashboard" if user["role"] == "admin" else "/student_dashboard")

        return "Invalid Login!"
    return render_template("login.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        conn = get_db()
        try:
            conn.execute("""
            INSERT INTO users(name,email,password,course,role,total_score)
            VALUES (?,?,?,?,?,0)
            """, (request.form["name"], request.form["email"],
                  request.form["password"], request.form["course"], "student"))
            conn.commit()
        except:
            return "Email already exists!"
        conn.close()
        return redirect("/login")

    return render_template("register.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect("/login")


# -----------------------------------------------
# SCORE, BADGES, STREAKS, STATS
# -----------------------------------------------
def recalc_total_score(user_id):
    """Only fully passed submissions count towards total_score."""
    conn = get_db()
    rows = conn.execute("""
    SELECT challenge_id, MAX(score) AS s
    FROM submissions
    WHERE user_id=? AND status='Passed'
    GROUP BY challenge_id
    """, (user_id,)).fetchall()

    total = sum(r["s"] for r in rows)
    conn.execute("UPDATE users SET total_score=? WHERE id=?", (total, user_id))
    conn.commit()
    conn.close()


def award_badges(user_id):
    conn = get_db()
    solved = conn.execute("""
    SELECT COUNT(DISTINCT challenge_id) AS s
    FROM submissions WHERE user_id=? AND status='Passed'
    """, (user_id,)).fetchone()["s"]

    badges = [
        (1, "Beginner"),
        (5, "Bronze"),
        (10, "Silver"),
        (20, "Gold"),
        (40, "Master")
    ]

    existing = {b["badge_name"] for b in conn.execute(
        "SELECT badge_name FROM badges WHERE user_id=?", (user_id,)
    ).fetchall()}

    for limit, name in badges:
        if solved >= limit and name not in existing:
            conn.execute("""
            INSERT INTO badges(user_id,badge_name,awarded_at)
            VALUES (?,?,?)
            """, (user_id, name, datetime.now().strftime("%Y-%m-%d %H:%M")))
            conn.commit()

    conn.close()


def update_streak(user_id):
    """Mark today's solve and manage streak table."""
    today = datetime.now().strftime("%Y-%m-%d")
    conn = get_db()
    conn.execute("""
    INSERT OR IGNORE INTO streaks(user_id,date)
    VALUES (?,?)
    """, (user_id, today))
    conn.commit()
    conn.close()


def calc_streak(user_id):
    """Return (current_streak, best_streak) based on streaks table."""
    conn = get_db()
    rows = conn.execute("""
    SELECT date FROM streaks
    WHERE user_id=?
    ORDER BY date ASC
    """, (user_id,)).fetchall()
    conn.close()

    if not rows:
        return 0, 0

    # Convert to datetime objects
    dates = [datetime.strptime(r["date"], "%Y-%m-%d").date() for r in rows]

    # Best streak & current streak
    best = 1
    current = 1

    for i in range(1, len(dates)):
        if dates[i] == dates[i-1] + timedelta(days=1):
            current += 1
        else:
            best = max(best, current)
            current = 1
    best = max(best, current)

    # current streak must end at today
    today = datetime.now().date()
    if dates[-1] == today:
        current_streak = 1
        for i in range(len(dates)-2, -1, -1):
            if dates[i+1] == dates[i] + timedelta(days=1):
                current_streak += 1
            else:
                break
    else:
        current_streak = 0

    return current_streak, best


def user_stats(user_id):
    conn = get_db()

    # User
    user = conn.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
    course = user["course"]

    # Total challenges
    total_ch = conn.execute("""
        SELECT COUNT(*) AS c FROM challenges WHERE course=?
    """, (course,)).fetchone()["c"]

    # Solved challenges
    solved = conn.execute("""
        SELECT COUNT(DISTINCT challenge_id) AS s
        FROM submissions
        WHERE user_id=? AND status='Passed'
    """, (user_id,)).fetchone()["s"]

    # User score
    total_score = user["total_score"]

    # Total time used for ranking
    total_time = conn.execute("""
        SELECT SUM(time_taken) AS t
        FROM submissions
        WHERE user_id=?
    """, (user_id,)).fetchone()["t"] or 0

    # -------------------------------
    # RANK CALCULATION:
    # Score DESC, Time ASC
    # -------------------------------
    rank = conn.execute("""
        SELECT COUNT(*) + 1 AS rnk
        FROM users u
        LEFT JOIN (
            SELECT user_id, SUM(time_taken) AS tt
            FROM submissions
            GROUP BY user_id
        ) AS T ON T.user_id = u.id
        WHERE u.role='student'
        AND (
            u.total_score > ?
            OR (u.total_score = ? AND IFNULL(T.tt, 99999999) < ?)
        )
    """, (total_score, total_score, total_time)).fetchone()["rnk"]

    # -------------------------------
    # RANK BADGES
    # -------------------------------
    if rank == 1:
        rank_badge = "🏆 Champion"
    elif rank <= 5:
        rank_badge = "🥇 Elite"
    elif rank <= 10:
        rank_badge = "🥈 Pro"
    else:
        rank_badge = None

    # -------------------------------
    # Badges
    # -------------------------------
    badges = conn.execute("""
        SELECT badge_name, awarded_at FROM badges
        WHERE user_id=? ORDER BY id DESC
    """, (user_id,)).fetchall()

    # -------------------------------
    # Leaderboard
    # -------------------------------
    leaderboard = conn.execute("""
        SELECT 
            u.name,
            u.total_score,
            IFNULL(SUM(s.time_taken), 0) AS total_time
        FROM users u
        LEFT JOIN submissions s ON u.id = s.user_id
        WHERE u.role='student'
        GROUP BY u.id
        ORDER BY u.total_score DESC, total_time ASC
        LIMIT 5
    """).fetchall()

    # -------------------------------
    # Module Certificates
    # -------------------------------
    modules = conn.execute("""
        SELECT module, COUNT(*) AS total
        FROM challenges
        WHERE course=?
        GROUP BY module
    """, (course,)).fetchall()

    module_certs = []
    for m in modules:
        mod_name = m["module"]
        total_mod = m["total"]

        solved_mod = conn.execute("""
            SELECT COUNT(DISTINCT s.challenge_id) AS s
            FROM submissions s
            JOIN challenges c ON s.challenge_id=c.id
            WHERE s.user_id=? AND s.status='Passed' AND c.module=?
        """, (user_id, mod_name)).fetchone()["s"]

        if total_mod > 0 and solved_mod >= 0.7 * total_mod:
            module_certs.append(mod_name)

    conn.close()

    # Certificate eligibility
    cert = (total_ch > 0 and solved >= 0.7 * total_ch)

    # Streaks
    streak, best_streak = calc_streak(user_id)

    return {
        "course": course,
        "total": total_ch,
        "solved": solved,
        "unsolved": max(total_ch - solved, 0),
        "score": total_score,
        "rank": rank,
        "rank_badge": rank_badge,   # <-- ADDED
        "badges": badges,
        "leaderboard": leaderboard,
        "cert": cert,
        "streak": streak,
        "best_streak": best_streak,
        "module_certs": module_certs,
        "total_time": total_time
    }



# -----------------------------------------------
# STUDENT DASHBOARD
# -----------------------------------------------
@app.route("/student_dashboard")
def student_dashboard():
    if "user_id" not in session:
        return redirect("/login")

    user_id = session["user_id"]
    stats = user_stats(user_id)

    conn = get_db()

    # 1️⃣ Get the student's course
    student_course = stats["course"]

    # 2️⃣ Try to load challenges for exact course
    challenges = conn.execute("""
        SELECT * FROM challenges WHERE course=?
    """, (student_course,)).fetchall()

    # 3️⃣ If no challenges found → try auto-correction
    if not challenges:
        print("⚠ No challenges found for:", student_course)

        # Map short forms to full forms automatically
        course_map = {
            "Python": "Python Full Stack",
            "Java": "Java Full Stack",
            "C": "C Programming",
            "C++": "C++ Programming",
            "DSA": "Data Structures",
            "Web": "Web Development"
        }

        # Auto convert if key exists
        if student_course in course_map:
            corrected = course_map[student_course]
            print("Auto-correcting:", student_course, "→", corrected)

            challenges = conn.execute("""
                SELECT * FROM challenges WHERE course=?
            """, (corrected,)).fetchall()

        # 4️⃣ Still empty? Show all challenges (fallback)
        if not challenges:
            print("⚠ Showing ALL challenges as fallback")
            challenges = conn.execute("""
                SELECT * FROM challenges
            """).fetchall()

    conn.close()

    return render_template(
        "student_dashboard.html",
        course=student_course,
        challenges=challenges,
        stats=stats
    )


# -----------------------------------------------
# ADMIN DASHBOARD
# -----------------------------------------------
@app.route("/admin_dashboard")
def admin_dashboard():
    if session.get("role") != "admin":
        return redirect("/login")

    conn = get_db()

    # All Challenges
    challenges = conn.execute("""
        SELECT * FROM challenges ORDER BY id DESC
    """).fetchall()

    # All Students (with status)
    students = conn.execute("""
        SELECT id, name, email, course, total_score, status
        FROM users
        WHERE role='student'
        ORDER BY total_score DESC
    """).fetchall()

    # All Submissions with challenge + username
    submissions = conn.execute("""
        SELECT 
            s.id, s.user_id, s.challenge_id, s.language, s.status, 
            s.score, s.time_taken, s.submitted_at,
            u.name AS user_name,
            c.title AS challenge_title
        FROM submissions s
        JOIN users u ON u.id = s.user_id
        JOIN challenges c ON c.id = s.challenge_id
        ORDER BY s.id DESC
    """).fetchall()

    # Leaderboard (Top 10)
    leaderboard = conn.execute("""
        SELECT name, total_score
        FROM users
        WHERE role='student'
        ORDER BY total_score DESC
        LIMIT 10
    """).fetchall()

    # Discussions (with usernames)
    discussions = conn.execute("""
        SELECT 
            d.id, d.challenge_id, d.user_id, d.comment, d.posted_at,
            u.name AS user_name,
            c.title AS challenge_title
        FROM discussions d
        JOIN users u ON u.id = d.user_id
        JOIN challenges c ON c.id = d.challenge_id
        ORDER BY d.id DESC
    """).fetchall()

    conn.close()

    return render_template(
        "admin_dashboard.html",
        challenges=challenges,
        students=students,
        submissions=submissions,
        leaderboard=leaderboard,
        discussions=discussions
    )




@app.route("/add_challenge", methods=["POST"])
def add_challenge():
    if session.get("role") != "admin":
        return redirect("/login")

    data = (
        request.form["course"],
        request.form["module"],
        request.form["title"],
        request.form["level"],
        request.form["description"],
        request.form["sample_input"],
        request.form["sample_output"],
        request.form["hidden_tests"],
        request.form["language"]
    )

    conn = get_db()

    conn.execute("""
        INSERT INTO challenges(course,module,title,level,description,sample_input,sample_output,hidden_tests,language)
        VALUES (?,?,?,?,?,?,?,?,?)
    """, data)

    conn.commit()
    conn.close()

    return redirect("/admin_dashboard")


@app.route("/edit_challenge/<int:cid>")
def edit_challenge(cid):
    if session.get("role") != "admin":
        return redirect("/login")

    conn = get_db()
    ch = conn.execute("SELECT * FROM challenges WHERE id=?", (cid,)).fetchone()
    conn.close()

    return render_template("edit_challenge.html", ch=ch)
@app.route("/update_challenge", methods=["POST"])
def update_challenge():
    if session.get("role") != "admin":
        return redirect("/login")

    cid = request.form["id"]

    conn = get_db()
    conn.execute("""
        UPDATE challenges SET 
            course=?, module=?, title=?, level=?, description=?,
            sample_input=?, sample_output=?, hidden_tests=?, language=?
        WHERE id=?
    """, (
        request.form["course"], request.form["module"], request.form["title"], request.form["level"],
        request.form["description"], request.form["sample_input"], request.form["sample_output"],
        request.form["hidden_tests"], request.form["language"], cid
    ))

    conn.commit()
    conn.close()

    return redirect("/admin_dashboard")

@app.route("/delete_challenge/<int:cid>")
def delete_challenge(cid):
    if session.get("role") != "admin":
        return redirect("/login")

    conn = get_db()
    conn.execute("DELETE FROM challenges WHERE id=?", (cid,))
    conn.commit()
    conn.close()

    return redirect("/admin_dashboard")
@app.route("/reset_password/<int:uid>")
def reset_password(uid):
    if session.get("role") != "admin":
        return redirect("/login")

    default_pwd = "123456"

    conn = get_db()
    conn.execute("UPDATE users SET password=? WHERE id=?", (default_pwd, uid))
    conn.commit()
    conn.close()

    return f"Password reset to: {default_pwd}"
@app.route("/block_user/<int:uid>")
def block_user(uid):
    if session.get("role") != "admin":
        return redirect("/login")

    conn = get_db()
    conn.execute("UPDATE users SET status='blocked' WHERE id=?", (uid,))
    conn.commit()
    conn.close()

    return redirect("/admin_dashboard")
@app.route("/unblock_user/<int:uid>")
def unblock_user(uid):
    if session.get("role") != "admin":
        return redirect("/login")

    conn = get_db()
    conn.execute("UPDATE users SET status='active' WHERE id=?", (uid,))
    conn.commit()
    conn.close()

    return redirect("/admin_dashboard")
@app.route("/delete_discussion/<int:did>")
def delete_discussion(did):
    if session.get("role") != "admin":
        return redirect("/login")

    conn = get_db()
    conn.execute("DELETE FROM discussions WHERE id=?", (did,))
    conn.commit()
    conn.close()

    return redirect("/admin_dashboard")




# -----------------------------------------------
# VIEW CHALLENGE + DISCUSSION
# -----------------------------------------------
@app.route("/challenge/<int:cid>")
def challenge_page(cid):
    conn = get_db()
    ch = conn.execute(
        "SELECT * FROM challenges WHERE id=?", (cid,)
    ).fetchone()

    comments = conn.execute("""
    SELECT d.*, u.name AS user_name
    FROM discussions d
    JOIN users u ON d.user_id=u.id
    WHERE d.challenge_id=?
    ORDER BY d.id DESC
    """, (cid,)).fetchall()
    conn.close()

    return render_template("challenge_editor.html",
                           challenge=ch,
                           comments=comments)


@app.route("/post_comment", methods=["POST"])
def post_comment():
    if "user_id" not in session:
        return redirect("/login")

    challenge_id = request.form["challenge_id"]
    comment = request.form["comment"]

    conn = get_db()
    conn.execute("""
    INSERT INTO discussions(challenge_id,user_id,comment,posted_at)
    VALUES (?,?,?,datetime('now'))
    """, (challenge_id, session["user_id"], comment))
    conn.commit()
    conn.close()

    return redirect(f"/challenge/{challenge_id}")


# -----------------------------------------------
# CODE EXECUTION ENGINE
# -----------------------------------------------
def run_code_exec(language, code, inp):
    """Runs user code for Run & Submit."""
    temp = uuid.uuid4().hex
    wd = TEMP_DIR

    # ---------------- Python ----------------
    if language == "Python":
        f = os.path.join(wd, f"{temp}.py")
        open(f, "w", encoding="utf-8").write(code)
        try:
            r = subprocess.run(["python", f],
                               input=inp,
                               text=True,
                               capture_output=True,
                               timeout=5)
            out = (r.stdout or "") + (r.stderr or "")
        except Exception as e:
            out = str(e)

        os.remove(f)
        return out.strip(), False

    # ---------------- C ----------------
    if language == "C":
        src = os.path.join(wd, f"{temp}.c")
        exe = os.path.join(wd, f"{temp}.exe")
        open(src, "w", encoding="utf-8").write(code)

        comp = subprocess.run(
            ["gcc", src, "-o", exe],
            capture_output=True, text=True
        )
        if comp.returncode != 0:
            os.remove(src)
            return comp.stderr.strip(), True

        r = subprocess.run([exe], input=inp, text=True,
                           capture_output=True, timeout=5)
        out = (r.stdout or "") + (r.stderr or "")
        os.remove(src)
        os.remove(exe)
        return out.strip(), False

    # ---------------- C++ ----------------
    if language == "C++":
        src = os.path.join(wd, f"{temp}.cpp")
        exe = os.path.join(wd, f"{temp}.exe")
        open(src, "w", encoding="utf-8").write(code)

        comp = subprocess.run(
            ["g++", src, "-o", exe],
            capture_output=True, text=True
        )
        if comp.returncode != 0:
            os.remove(src)
            return comp.stderr.strip(), True

        r = subprocess.run([exe], input=inp, text=True,
                           capture_output=True, timeout=5)
        out = (r.stdout or "") + (r.stderr or "")
        os.remove(src)
        os.remove(exe)
        return out.strip(), False

    # ---------------- JAVA ----------------
    if language == "Java":
        java = os.path.join(wd, "Main.java")
        open(java, "w", encoding="utf-8").write(code)

        comp = subprocess.run(
            ["javac", "Main.java"], cwd=wd,
            capture_output=True, text=True
        )
        if comp.returncode != 0:
            if os.path.exists(java):
                os.remove(java)
            if os.path.exists(os.path.join(wd, "Main.class")):
                os.remove(os.path.join(wd, "Main.class"))
            return comp.stderr.strip(), True

        r = subprocess.run(
            ["java", "Main"], cwd=wd, input=inp,
            text=True, capture_output=True, timeout=5
        )
        out = (r.stdout or "") + (r.stderr or "")

        if os.path.exists(java):
            os.remove(java)
        if os.path.exists(os.path.join(wd, "Main.class")):
            os.remove(os.path.join(wd, "Main.class"))

        return out.strip(), False

    return "Invalid language", True


# -----------------------------------------------
# RUN BUTTON (Sample test + basic logic check)
# -----------------------------------------------
@app.route("/run_code", methods=["POST"])
def run_code():
    code = request.form["code"]
    lang = request.form["language"]
    sample_in = request.form.get("sample_input", "")
    expected = request.form.get("expected_output", "").strip()
    challenge_id = request.form.get("challenge_id")

    out, _ = run_code_exec(lang, code, sample_in)
    sample_match = (out.strip() == expected)

    # Basic logic flag — if sample failed, logic_failed = True
    logic_failed = not sample_match

    # Save code snapshot in history (RUN)
    if "user_id" in session and challenge_id:
        conn = get_db()
        conn.execute("""
        INSERT INTO code_history(user_id,challenge_id,code,action,timestamp)
        VALUES (?,?,?,?,datetime('now'))
        """, (session["user_id"], challenge_id, code, "run"))
        conn.commit()
        conn.close()

    return jsonify({
        "output": out,
        "expected": expected,
        "sample_match": sample_match,
        "logic_failed": logic_failed
    })


# -----------------------------------------------
# SUBMIT BUTTON (Hidden testcases, score, XP, streak)
# -----------------------------------------------
@app.route("/submit_code", methods=["POST"])
def submit_code():
    if "user_id" not in session:
        return jsonify({"error": "Login required"})

    code = request.form["code"]
    lang = request.form["language"]
    challenge_id = request.form["challenge_id"]
    uid = session["user_id"]
    time_taken = int(request.form.get("time_taken", "0") or 0)

    conn = get_db()
    ch = conn.execute("SELECT * FROM challenges WHERE id=?", (challenge_id,)).fetchone()

    lines = [l for l in (ch["hidden_tests"] or "").splitlines() if "||" in l]
    total = len(lines)
    if total == 0:
        conn.close()
        return jsonify({"status": "Error", "message": "No hidden tests configured", "score": 0})

    passed = 0
    results = []

    for i, test in enumerate(lines, 1):
        inp, exp = test.split("||", 1)
        out, _ = run_code_exec(lang, code, inp)
        ok = (out.strip() == exp.strip())

        if ok:
            passed += 1

        results.append({"test": i, "result": "Passed" if ok else "Failed"})

    score = int((passed / total) * 100)
    status = "Passed" if passed == total else "Failed"

    # Store submission
    conn.execute("""
    INSERT INTO submissions(user_id,challenge_id,code,language,status,score,time_taken,submitted_at)
    VALUES (?,?,?,?,?,?,?,datetime('now'))
    """, (uid, challenge_id, code, lang, status, score, time_taken))
    conn.commit()

    # Save to code history
    conn.execute("""
    INSERT INTO code_history(user_id,challenge_id,code,action,timestamp)
    VALUES (?,?,?,?,datetime('now'))
    """, (uid, challenge_id, code, "submit"))
    conn.commit()
    conn.close()

    # Only fully Passed solutions affect XP, badges, streak
    if status == "Passed":
        recalc_total_score(uid)
        award_badges(uid)
        update_streak(uid)

    return jsonify({
        "status": status,
        "score": score,
        "passed": passed,
        "total": total,
        "tests": results
    })


# -----------------------------------------------
# CERTIFICATE ROUTES
# -----------------------------------------------
@app.route("/certificate")
def certificate():
    if "user_id" not in session:
        return redirect("/login")

    stats = user_stats(session["user_id"])
    if not stats["cert"]:
        return "Not eligible for full course certificate yet!"

    return render_template("certificate.html",
                           student_name=session["name"],
                           course=session["course"],
                           date=datetime.now().strftime("%d-%m-%Y"))


@app.route("/module_certificate/<module>")
def module_certificate(module):
    if "user_id" not in session:
        return redirect("/login")

    uid = session["user_id"]
    conn = get_db()

    row = conn.execute("""
    SELECT COUNT(*) AS total FROM challenges
    WHERE module=? AND course=?
    """, (module, session["course"])).fetchone()
    total_mod = row["total"]

    solved_mod = conn.execute("""
    SELECT COUNT(DISTINCT s.challenge_id) AS s
    FROM submissions s
    JOIN challenges c ON s.challenge_id=c.id
    WHERE s.user_id=? AND s.status='Passed' AND c.module=?
    """, (uid, module)).fetchone()["s"]
    conn.close()

    if total_mod == 0 or solved_mod < 0.7 * total_mod:
        return f"Not eligible for {module} certificate yet!"

    return render_template("certificate.html",
                           student_name=session["name"],
                           course=module,
                           date=datetime.now().strftime("%d-%m-%Y"))
@app.route("/history/<int:challenge_id>")
def view_history(challenge_id):
    if "user_id" not in session:
        return redirect("/login")

    uid = session["user_id"]
    conn = get_db()

    logs = conn.execute("""
    SELECT * FROM code_history
    WHERE user_id=? AND challenge_id=?
    ORDER BY id DESC
    """, (uid, challenge_id)).fetchall()

    conn.close()

    return render_template("history.html", logs=logs, challenge_id=challenge_id)
@app.route("/revert_code", methods=["POST"])
def revert_code():
    if "user_id" not in session:
        return jsonify({"error": "Login required"})

    snapshot_id = request.form["snapshot_id"]

    conn = get_db()
    row = conn.execute("""
    SELECT code FROM code_history WHERE id=?
    """, (snapshot_id,)).fetchone()
    conn.close()

    if not row:
        return jsonify({"error": "Snapshot not found"})

    return jsonify({"code": row["code"]})

@app.route("/history_all")
def history_all():
    if "user_id" not in session:
        return redirect("/login")

    uid = session["user_id"]
    conn = get_db()

    logs = conn.execute("""
    SELECT h.*, c.title AS challenge_title
    FROM code_history h
    JOIN challenges c ON h.challenge_id = c.id
    WHERE h.user_id=?
    ORDER BY h.id DESC
    """, (uid,)).fetchall()

    conn.close()

    return render_template("history_all.html", logs=logs)

# -----------------------------------------------
# RUN APP
# -----------------------------------------------
if __name__ == "__main__":
    app.run(debug=True)
